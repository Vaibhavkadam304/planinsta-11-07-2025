"use server"

import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import OpenAI from "openai"
import { z } from "zod"
import type { BusinessPlanData, GeneratedPlan } from "@/app/plan-builder/PlanBuilderClient"

// ──────────────────────────────────────────────────────────────
// Helpers (balanced expansion/compression)
// ──────────────────────────────────────────────────────────────

type OpenAIClient = InstanceType<typeof OpenAI>;

function stripFences(text: string): string {
  let t = (text ?? "").trim()
  if (t.startsWith("```")) t = t.replace(/^```(?:json)?\r?\n/, "")
  if (t.endsWith("```")) t = t.replace(/\r?\n```$/, "")
  return t.trim()
}
const ensure = (s?: string, fallback = "") =>
  typeof s === "string" && s.trim().length > 0 ? s : fallback

const getByPath = (obj: any, path: string) =>
  path.split(".").reduce((o, k) => (o ? o[k] : undefined), obj)

const setByPath = (obj: any, path: string, value: string) => {
  const parts = path.split(".")
  const last = parts.pop() as string
  const parent = parts.reduce((o, k) => (o[k] ??= {}), obj)
  parent[last] = value
}

const wc = (s: string) => (s || "").trim().split(/\s+/).filter(Boolean).length

// Hard truncate to word boundary
function takeFirstWords(s: string, maxWords: number) {
  const words = s.trim().split(/\s+/)
  if (words.length <= maxWords) return s.trim()
  return words.slice(0, maxWords).join(" ").replace(/[.,;:!?-]*$/, "") + "…"
}

// Simple emoji remover (safety for any user-provided strings)
function stripEmojis(s: string) {
  try {
    return (s || "").replace(/[\p{Extended_Pictographic}]/gu, "")
  } catch {
    return s || ""
  }
}

// ── Amount helpers ──
function parseAmount(s?: string): number {
  if (!s) return 0
  const clean = String(s).replace(/[^0-9.]/g, "")
  const n = Number(clean || 0)
  return Number.isFinite(n) ? n : 0
}
function toAmountString(n: number): string {
  return Math.round(n).toLocaleString("en-US")
}

// Balance targets (XS = ~4–5 lines per subsection)
const BALANCE_TARGETS: Record<string, { min: number; max: number }> = {
  // Executive Summary
  "executiveSummary.businessOverview": { min: 60, max: 90 },
  "executiveSummary.fundingRequirementsUsageOfFunds": { min: 60, max: 90 },
  "executiveSummary.pastMilestones": { min: 55, max: 80 },
  "executiveSummary.problemStatementSolution": { min: 55, max: 80 },

  // Company Overview
  "companyOverview.visionStatement": { min: 50, max: 80 },
  "companyOverview.missionStatement": { min: 50, max: 80 },
  "companyOverview.companyHistoryBackground": { min: 55, max: 85 },
  "companyOverview.foundingTeam": { min: 50, max: 80 },
  "companyOverview.legalStructureOwnership": { min: 45, max: 75 },
  "companyOverview.coreValuesCulture": { min: 50, max: 80 },
  "companyOverview.companyObjectives": { min: 50, max: 80 },

  // Products (string fields)
  "products.overview": { min: 60, max: 90 },
  "products.uniqueSellingPropositions": { min: 50, max: 80 },
  "products.developmentRoadmap": { min: 50, max: 80 },
  "products.intellectualPropertyRegulatoryStatus": { min: 45, max: 75 },

  // Market Analysis
  "marketAnalysis.industryOverviewSize": { min: 60, max: 90 },
  "marketAnalysis.growthTrendsDrivers": { min: 60, max: 90 },
  "marketAnalysis.underlyingBusinessDrivers": { min: 55, max: 85 },
  "marketAnalysis.targetMarketSegmentation": { min: 55, max: 85 },
  "marketAnalysis.customerPersonasNeeds": { min: 55, max: 85 },
  "marketAnalysis.competitiveLandscapePositioning": { min: 55, max: 85 },
  "marketAnalysis.productsDifferentiation": { min: 50, max: 80 },
  "marketAnalysis.barriersToEntry": { min: 50, max: 80 },

  // Marketing & Sales
  "marketingSalesStrategies.distributionChannels": { min: 60, max: 90 },
  "marketingSalesStrategies.retentionStrategies": { min: 60, max: 90 },
  "marketingSalesStrategies.technologyCostStructure": { min: 50, max: 80 },
  "marketingSalesStrategies.customerPricingStructure": { min: 50, max: 80 },
  "marketingSalesStrategies.integratedFunnelFinancialImpact": { min: 55, max: 85 },

  // Operations Plan
  "operationsPlan.overview": { min: 55, max: 85 },
  "operationsPlan.organizationalStructureTeamResponsibilities": { min: 55, max: 85 },
  "operationsPlan.infrastructure": { min: 55, max: 85 },
  "operationsPlan.customerOnboardingToRenewalWorkflow": { min: 55, max: 85 },
  "operationsPlan.crossFunctionalCommunicationDecisionMaking": { min: 55, max: 85 },
  "operationsPlan.keyPerformanceMetricsGoals": { min: 55, max: 85 },

  // Management & Organization
  "managementOrganization.overview": { min: 50, max: 80 },
  "managementOrganization.organizationalChart": { min: 50, max: 80 },
  "managementOrganization.hiringPlanKeyRoles": { min: 50, max: 80 },

  // Financial Plan (string fields only)
  "financialPlan.overview": { min: 55, max: 85 },
  "financialPlan.keyAssumptions": { min: 55, max: 85 },
  "financialPlan.keyFinancialMetricsRatios": { min: 55, max: 85 },
  "financialPlan.useOfFundsRunway": { min: 55, max: 85 },
  "financialPlan.keySensitivityRiskScenarios": { min: 60, max: 90 },
  "financialPlan.summaryOutlook": { min: 60, max: 90 },

  // Risk
  "riskAnalysisMitigation.overview": { min: 60, max: 90 },
  "riskAnalysisMitigation.marketRisks": { min: 60, max: 90 },
  "riskAnalysisMitigation.operationalRisks": { min: 60, max: 90 },
  "riskAnalysisMitigation.regulatoryLegalRisks": { min: 60, max: 90 },
  "riskAnalysisMitigation.financialRisks": { min: 60, max: 90 },
  "riskAnalysisMitigation.contingencyPlans": { min: 60, max: 90 },

  // Appendices
  "appendices.glossary": { min: 40, max: 60 },
  "appendices.managementTeamsResources": { min: 40, max: 60 },
  "appendices.projectedFinancesTables": { min: 40, max: 60 },
}
for (let i = 1; i <= 10; i++) {
  BALANCE_TARGETS[`products.product${i}`] = { min: 35, max: 55 }
}

// ── Structured markdown fields (no emojis) ──
const STRUCTURED_MARKDOWN_FIELDS = new Set<string>([
  "executiveSummary.businessOverview",
  "executiveSummary.fundingRequirementsUsageOfFunds",
])

function structuredMarkdownGuidance(path: string) {
  if (path === "executiveSummary.businessOverview") {
    return `Formatting:
- Start with a 1–2 sentence paragraph about the company.
- Then add a bold subhead **Key Highlights** followed by hyphen bullets (no emojis).
- Then add a bold subhead **Our Mission** followed by hyphen bullets (no emojis).`
  }
  if (path === "executiveSummary.fundingRequirementsUsageOfFunds") {
    return `Formatting:
- Start with one sentence stating the total funding required.
- Then add a bold subhead **Allocation of Funds** with hyphen bullets "<Item> — <Amount>" that sum EXACTLY to fundingNeeded (digits/commas only).
- Then add a bold subhead **Objective** with 2–4 hyphen bullets (no emojis).`
  }
  return ""
}

// ──────────────────────────────────────────────────────────────
// Retry wrapper
// ──────────────────────────────────────────────────────────────
async function withRetries<T>(fn: () => Promise<T>) {
  let attempt = 0
  const maxRetries = 5
  while (true) {
    try {
      return await fn()
    } catch (err: any) {
      const status = err?.status ?? err?.response?.status
      const code = err?.code
      const headers = err?.headers ?? err?.response?.headers
      const transient =
        status === 429 || (status && status >= 500) ||
        code === "ENOTFOUND" || code === "ECONNRESET" || code === "ETIMEDOUT"
      if (!transient || attempt >= maxRetries) throw err
      const ra = Number(headers?.["retry-after"])
      const base = 800 + attempt * 600
      const jitter = Math.random() * 250
      await new Promise(r => setTimeout(r, Number.isFinite(ra) ? ra * 1000 : base + jitter))
      attempt++
    }
  }
}

// ──────────────────────────────────────────────────────────────
// Expansion / Compression
// ──────────────────────────────────────────────────────────────

async function expandToRange({
  client,
  model,
  original,
  min,
  max,
  formData,
  path,
  allowMarkdown = false,
}: {
  client: OpenAIClient
  model: string
  original: string
  min: number
  max: number
  formData: any
  path: string
  allowMarkdown?: boolean
}) {
  let text = original.trim()

  for (let i = 0; i < 3 && wc(text) < min; i++) {
    const formattingRule = allowMarkdown
      ? `Use MARKDOWN only where appropriate:
- Keep any existing bold subheads and hyphen bullets.
- No emojis anywhere.
${structuredMarkdownGuidance(path)}`
      : `Return PLAIN TEXT (no headings/markdown).`

    const sys = `You expand business-plan prose.
Rules:
- Target ${min}–${max} words.
- Keep meaning; add specifics/examples; avoid fluff.
- ${formattingRule}`
    const usr = `COMPANY CONTEXT:
${JSON.stringify({
  businessName: formData.businessName,
  model: formData.businessModel,
  location: formData.location,
  audience: formData.targetAudience,
  pricing: formData.pricingStrategy,
  channels: formData.marketingChannels,
}, null, 2)}

SECTION (${path}) — CURRENT TEXT:
${text}

TASK: Rewrite to ${min}–${max} words. Return only the text (markdown allowed only per rules).`
    const res = await withRetries(() =>
      client.chat.completions.create({
        model,
        temperature: 0.3,
        max_tokens: 1100,
        messages: [
          { role: "system", content: sys },
          { role: "user", content: usr },
        ],
      })
    )
    text = stripFences(res.choices?.[0]?.message?.content ?? "").trim()
  }

  if (wc(text) < min) {
    const addSys = allowMarkdown
      ? `Add 1–3 concise sentences to reach at least ${min} words but not exceed ${max}. Keep existing markdown structure; no emojis.`
      : `Add 1–3 concise sentences to reach at least ${min} words but not exceed ${max}. Plain text only.`
    const addUsr = `SECTION (${path}) — CURRENT TEXT:\n${text}\n\nAdditions (not a rewrite):`
    const add = await withRetries(() =>
      client.chat.completions.create({
        model,
        temperature: 0.4,
        max_tokens: 180,
        messages: [
          { role: "system", content: addSys },
          { role: "user", content: addUsr },
        ],
      })
    )
    text = (text + " " + stripFences(add.choices?.[0]?.message?.content ?? "").trim()).trim()
    if (wc(text) > max) text = takeFirstWords(text, max)
  }

  return text
}

async function compressToMaxStrict({
  client,
  model,
  original,
  max,
  formData,
  path,
  passes = 3,
  allowMarkdown = false,
}: {
  client: OpenAIClient
  model: string
  original: string
  max: number
  formData: any
  path: string
  passes?: number
  allowMarkdown?: boolean
}) {
  let text = original.trim()
  for (let i = 0; i < passes && wc(text) > max; i++) {
    const formattingRule = allowMarkdown
      ? `Keep existing MARKDOWN structure (bold subheads, hyphen bullets). No emojis.`
      : `Return PLAIN TEXT (no headings/markdown).`

    const sys = `You condense business-plan prose.
Rules:
- HARD LIMIT: ≤ ${max} words.
- Preserve key facts and structure; keep it cohesive and specific.
- ${formattingRule}`
    const usr = `COMPANY CONTEXT:
${JSON.stringify({
  businessName: formData.businessName,
  model: formData.businessModel,
  location: formData.location,
  audience: formData.targetAudience,
}, null, 2)}

SECTION (${path}) — CURRENT TEXT:
${text}

TASK: Rewrite to ≤ ${max} words. Return only the rewritten text.`
    const res = await withRetries(() =>
      client.chat.completions.create({
        model,
        temperature: 0.2,
        max_tokens: 500,
        messages: [
          { role: "system", content: sys },
          { role: "user", content: usr },
        ],
      })
    )
    text = stripFences(res.choices?.[0]?.message?.content ?? "").trim()
  }
  if (wc(text) > max) text = takeFirstWords(text, max)
  return text
}

// Main balancer (logs + strict compression)
async function balancePlanSections({
  client,
  model,
  plan,
  formData,
  enable = true,
}: {
  client: OpenAIClient
  model: string
  plan: any
  formData: any
  enable?: boolean
}) {
  if (!enable) return
  const LOG = (process.env.BALANCE_LOG ?? "0") === "1"

  for (const [path, { min, max }] of Object.entries(BALANCE_TARGETS)) {
    const cur = String(getByPath(plan, path) ?? "")
    if (!cur.trim()) continue
    const words = wc(cur)
    const allowMarkdown = STRUCTURED_MARKDOWN_FIELDS.has(path)

    try {
      if (words < min) {
        if (LOG) console.log(`[balance] EXPAND ${path}: ${words} → target ${min}-${max}`)
        const expanded = await expandToRange({ client, model, original: cur, min, max, formData, path, allowMarkdown })
        if (expanded && wc(expanded) >= min) setByPath(plan, path, expanded)
      } else if (words > max) {
        if (LOG) console.log(`[balance] COMPRESS ${path}: ${words} → max ${max}`)
        const compressed = await compressToMaxStrict({ client, model, original: cur, max, formData, path, allowMarkdown })
        if (compressed) setByPath(plan, path, compressed)
      } else {
        if (LOG) console.log(`[balance] OK ${path}: ${words} within ${min}-${max}`)
      }
    } catch (e) {
      if (LOG) console.warn(`balancePlanSections(${path}) skipped:`, e)
      // keep original on error
    }
  }
}

// ──────────────────────────────────────────────────────────────
// Financial normalizer (post-parse guardrail)
// ──────────────────────────────────────────────────────────────
function normalizeFinancials(plan: any, formData: any) {
  const fundingNeededN =
    parseAmount(plan.fundingNeeded) || parseAmount(formData?.fundingNeeded)

  // Build a use-of-funds array from formData.fundingUseBreakdown if present
  const rawFub = Array.isArray(formData?.fundingUseBreakdown) ? formData.fundingUseBreakdown : []
  const breakdown: Array<{ item: string; amountN: number }> = []
  for (const r of rawFub) {
    const item = stripEmojis((r?.item ?? "").trim())
    const amtN = parseAmount(r?.amount)
    if (item && amtN > 0) breakdown.push({ item, amountN: amtN })
  }

  // If no user breakdown provided, try to infer from investmentUtilization
  if (!breakdown.length && Array.isArray(formData?.investmentUtilization)) {
    for (const r of formData.investmentUtilization) {
      const item = stripEmojis((r?.item ?? "").trim())
      const amtN = parseAmount(r?.amount)
      if (item && amtN > 0) breakdown.push({ item, amountN: amtN })
    }
  }

  // If we still have nothing but fundingNeeded, create a single bucket
  if (!breakdown.length && fundingNeededN > 0) {
    breakdown.push({ item: "Working capital and contingency", amountN: fundingNeededN })
  }

  // Make total match fundingNeeded if present
  if (fundingNeededN > 0 && breakdown.length) {
    let sum = breakdown.reduce((a, b) => a + b.amountN, 0)
    if (sum < fundingNeededN) {
      breakdown.push({
        item: "Working capital and contingency",
        amountN: fundingNeededN - sum,
      })
    } else if (sum > fundingNeededN) {
      const excess = sum - fundingNeededN
      const last = breakdown[breakdown.length - 1]
      last.amountN = Math.max(0, last.amountN - excess)
      if (last.amountN === 0) breakdown.pop()
    }
  }

  // OpEx alignment with monthlyExpenses (if provided)
  const monthlyExpN = parseAmount(formData?.monthlyExpenses)
  if (monthlyExpN > 0 && Array.isArray(plan.financialPlan?.opEx)) {
    for (const row of plan.financialPlan.opEx) {
      if (row && typeof row === "object") {
        row.amount = toAmountString(monthlyExpN)
      }
    }
  }

  // Ensure Month 1 beginning cash aligns with initialInvestment if present
  const initCashN =
    parseAmount(plan.initialInvestment) || parseAmount(formData?.initialInvestment)
  if (initCashN > 0 && Array.isArray(plan.financialPlan?.cashFlowRunwayAnalysis) && plan.financialPlan.cashFlowRunwayAnalysis[0]) {
    plan.financialPlan.cashFlowRunwayAnalysis[0].beginningCash = toAmountString(initCashN)
  }

  // ── Rewrite funding sections with consistent, emoji-free markdown ──
  if (fundingNeededN > 0 && breakdown.length) {
    const mdList = breakdown
      .map(b => `- ${stripEmojis(b.item)} — ${toAmountString(b.amountN)}`)
      .join("\n")

    const company = stripEmojis((formData?.businessName || "the company").trim())

    // Optional objectives from formData; else defaults
    const objectives: string[] = Array.isArray((formData as any)?.fundingObjectives)
      ? ((formData as any).fundingObjectives as string[]).map(x => stripEmojis(String(x || "").trim())).filter(Boolean)
      : []

    if (!objectives.length) {
      objectives.push(
        "Strengthen product-market fit",
        "Expand the user base through effective outreach",
        "Establish a foundation for long-term sustainable growth",
      )
    }

    const execFunding = [
      `We are seeking ${toAmountString(fundingNeededN)} in funding to accelerate the growth and development of ${company}.`,
      ``,
      `**Allocation of Funds**`,
      mdList,
      ``,
      `**Objective**`,
      ...objectives.map(o => `- ${o}`),
    ].join("\n")

    plan.executiveSummary.fundingRequirementsUsageOfFunds = execFunding

    // Financial Plan version (kept simple list)
    plan.financialPlan.useOfFundsRunway = [
      `Planned use of funds totals ${toAmountString(fundingNeededN)} and is allocated to:`,
      mdList,
    ].join("\n")
  }
}

// Optional: enforce structured Business Overview (intro + highlights + mission)
function structureExecBusinessOverview(plan: any, formData: any) {
  const original = String(plan?.executiveSummary?.businessOverview || "").trim()
  const intro =
    stripEmojis((formData as any)?.execIntro || "") ||
    (original ? original.split(/\.\s/).slice(0, 1).join(". ") + "." : "")

  // Highlights: prefer user-provided execHighlights; else use achievements; else none
  const highlights: string[] = Array.isArray((formData as any)?.execHighlights)
    ? (formData as any).execHighlights.map((x: string) => stripEmojis(String(x || "").trim())).filter(Boolean)
    : Array.isArray((formData as any)?.achievements)
      ? (formData as any).achievements.map((x: string) => stripEmojis(String(x || "").trim())).filter(Boolean)
      : []

  // Mission bullets (user-provided or defaults)
  const missionBullets: string[] = Array.isArray((formData as any)?.missionBullets)
    ? (formData as any).missionBullets.map((x: string) => stripEmojis(String(x || "").trim())).filter(Boolean)
    : [
        "Save valuable time and resources",
        "Boost productivity and growth",
        "Focus on what matters most — running their business, not their tools",
      ]

  const parts = [
    intro,
    "",
    "**Key Highlights**",
    ...highlights.map(h => `- ${h}`),
    "",
    "**Our Mission**",
    ...missionBullets.map(m => `- ${m}`),
  ]

  plan.executiveSummary.businessOverview = parts.join("\n").trim()
}

// ──────────────────────────────────────────────────────────────
// Enforcement: guarantee inclusion of key facts in prose
// ──────────────────────────────────────────────────────────────
function includeIfMissing(haystack: string, needle: string) {
  const h = (haystack || "").trim()
  if (!needle || h.includes(needle)) return h
  const sep = h.endsWith(".") ? " " : (h ? ". " : "")
  return (h + sep + needle).trim()
}

function enforceInclusions(plan: any, formData: any) {
  // === existing code you already have (fundingReceived, investmentUtilization, notes, upcomingMilestone) ===

  // ── Location (country/region) → Company History; Operation location → Ops Overview
  const loc = (formData?.location || "").trim()
  if (loc) {
    const sentence = `Headquartered in ${loc}.`
    plan.companyOverview.companyHistoryBackground =
      includeIfMissing(plan.companyOverview.companyHistoryBackground, sentence)
  }
  const opLoc = (formData as any)?.operationLocation?.trim?.()
  if (opLoc) {
    const sentence = `Operations are based in ${opLoc}.`
    plan.operationsPlan.overview =
      includeIfMissing(plan.operationsPlan.overview, sentence)
  }

  // ── Business stage → Company Objectives
  const stage = (formData?.businessStage || "").trim()
  if (stage) {
    const sentence = `Current stage: ${stage}.`
    plan.companyOverview.companyObjectives =
      includeIfMissing(plan.companyOverview.companyObjectives, sentence)
  }

  // ── Founder role → Founding Team
  const founderRole = (formData?.founderRole || "").trim()
  if (founderRole) {
    const sentence = `Founder's role: ${founderRole}.`
    plan.companyOverview.foundingTeam =
      includeIfMissing(plan.companyOverview.foundingTeam, sentence)
  }

  // ── Description → Company History (kept as a plain sentence)
  const description = (formData?.description || "").trim()
  if (description) {
    const sentence = /[.?!]$/.test(description) ? description : `${description}.`
    plan.companyOverview.companyHistoryBackground =
      includeIfMissing(plan.companyOverview.companyHistoryBackground, sentence)
  }

  // ── Root-level USPs / key features → Products → Unique Selling Propositions
  const uspRoot = (formData as any)?.uniqueSellingPoint?.trim?.() || ""
  const keyFeatures = Array.isArray((formData as any)?.keyFeatures)
    ? (formData as any).keyFeatures.map((x: string) => String(x || "").trim()).filter(Boolean)
    : []

  if (uspRoot || keyFeatures.length) {
    let uspText = String(plan.products.uniqueSellingPropositions || "")
    if (uspRoot) {
      uspText = includeIfMissing(uspText, `Unique selling point: ${uspRoot}.`)
    }
    if (keyFeatures.length) {
      const featuresSentence = `Key features: ${keyFeatures.join(", ")}.`
      uspText = includeIfMissing(uspText, featuresSentence)
    }
    plan.products.uniqueSellingPropositions = uspText
  }
}


// ──────────────────────────────────────────────────────────────
// Schema
// ──────────────────────────────────────────────────────────────
const businessPlanSchema = z.object({
  coverPage: z.object({
    logo: z.string(),
  }),
  executiveSummary: z.object({
    businessOverview: z.string(),
    fundingRequirementsUsageOfFunds: z.string(),
    pastMilestones: z.string(),
    problemStatementSolution: z.string(),
  }),
  companyOverview: z.object({
    visionStatement: z.string(),
    missionStatement: z.string(),
    companyHistoryBackground: z.string(),
    foundingTeam: z.string(),
    legalStructureOwnership: z.string(),
    coreValuesCulture: z.string(),
    companyObjectives: z.string(),
  }),
  products: z.object({
    overview: z.string(),
    product1: z.string(),
    product2: z.string(),
    product3: z.string(),
    product4: z.string(),
    product5: z.string(),
    product6: z.string(),
    product7: z.string(),
    product8: z.string(),
    product9: z.string(),
    product10: z.string(),
    uniqueSellingPropositions: z.string(),
    developmentRoadmap: z.string(),
    intellectualPropertyRegulatoryStatus: z.string(),
  }),
  marketAnalysis: z.object({
    industryOverviewSize: z.string(),
    growthTrendsDrivers: z.string(),
    underlyingBusinessDrivers: z.string(),
    targetMarketSegmentation: z.string(),
    customerPersonasNeeds: z.string(),
    competitiveLandscapePositioning: z.string(),
    productsDifferentiation: z.string(),
    barriersToEntry: z.string(),
  }),
  marketingSalesStrategies: z.object({
    distributionChannels: z.string(),
    technologyCostStructure: z.string(),
    customerPricingStructure: z.string(),
    retentionStrategies: z.string(),
    integratedFunnelFinancialImpact: z.string(),
  }),
  operationsPlan: z.object({
    overview: z.string(),
    organizationalStructureTeamResponsibilities: z.string(),
    infrastructure: z.string(),
    customerOnboardingToRenewalWorkflow: z.string(),
    crossFunctionalCommunicationDecisionMaking: z.string(),
    keyPerformanceMetricsGoals: z.string(),
  }),
  managementOrganization: z.object({
    overview: z.string(),
    organizationalChart: z.string(),
    hiringPlanKeyRoles: z.string(),
  }),
  financialPlan: z.object({
    overview: z.string(),
    keyAssumptions: z.string(),
    revenueForecast: z.array(z.object({ period: z.string(), amount: z.string() })),
    cogs: z.array(z.object({ period: z.string(), amount: z.string() })),
    opEx: z.array(z.object({ period: z.string(), amount: z.string() })),
    projectedPnl: z.array(
      z.object({ period: z.string(), grossProfit: z.string(), ebitda: z.string(), netIncome: z.string() })
    ),
    cashFlowRunwayAnalysis: z.array(z.object({
      period: z.string(),
      beginningCash: z.string(),
      inflows: z.string(),
      outflows: z.string(),
      endingCash: z.string(),
      runwayMonths: z.string(),
    })),
    keyFinancialMetricsRatios: z.string(),
    useOfFundsRunway: z.string(),
    keySensitivityRiskScenarios: z.string(),
    summaryOutlook: z.string(),
  }),
  riskAnalysisMitigation: z.object({
    overview: z.string(),
    marketRisks: z.string(),
    operationalRisks: z.string(),
    regulatoryLegalRisks: z.string(),
    financialRisks: z.string(),
    contingencyPlans: z.string(),
  }),
  appendices: z.object({
    glossary: z.string(),
    managementTeamsResources: z.string(),
    projectedFinancesTables: z.string(),
  }),

  // Root-level fields
  initialInvestment: z.string().optional().default(""),
  fundingNeeded: z.string().optional().default(""),
  fundingReceived: z.string().optional().default(""),
  monthlyRevenue: z.string().optional().default(""),
  investmentUtilization: z.array(z.object({ item: z.string(), amount: z.string() })).optional().default([]),

  // ✅ NEW root fields
  notes: z.string().optional().default(""),
  upcomingMilestone: z.string().optional().default(""),
})

export type GenerateBusinessPlanResult =
  | { success: true; plan: GeneratedPlan; planId: string }
  | { success: false; error: string }

// ──────────────────────────────────────────────────────────────
// Main action
// ──────────────────────────────────────────────────────────────
export async function generateBusinessPlan(
  formData: BusinessPlanData
): Promise<GenerateBusinessPlanResult> {
  try {
    // Supabase
    const cookiesStore = await cookies()
    const supabase = createServerComponentClient({ cookies: () => cookiesStore })

    // Hints for marketing section
    const selectedChannels = Array.isArray(formData.marketingChannels)
      ? formData.marketingChannels.filter(Boolean)
      : []
    const pricingHint = (formData.pricingStrategy || "").trim()
    const salesTeamHint = formData.hasSalesTeam ? "Yes" : "No"

    const marketingUserHints = `
    USER HINTS FOR MARKETING & SALES (weave into one subsection only):
    • Selected marketing channels: ${selectedChannels.length ? selectedChannels.join(", ") : "not specified"}
    ${pricingHint ? `• Pricing: ${pricingHint}` : "" }
    • Sales team: ${salesTeamHint}
    IMPORTANT: Incorporate the hints above naturally into the **Distribution Channels** subsection (its first paragraph). Do not create extra subsections or separate bullet groups for these hints.
    `
    // Achievements
    const achievements = (formData.achievements ?? []).map(a => a?.trim()).filter(Boolean)
    const achievementsHint = achievements.length
      ? `USER HINTS FOR EXECUTIVE SUMMARY → Past Milestones:
• Weave these achievements into the first paragraph (no extra bullets): ${achievements.join(", ")}`
      : ""

    // Finance facts → to be woven
    const financeFacts = (() => {
      const lines: string[] = []
      const fd: any = formData as any

      if (fd.initialInvestment) lines.push(`- Initial investment: ${fd.initialInvestment}`)
      if (fd.fundingReceived)   lines.push(`- Funding received: ${fd.fundingReceived}`)
      if (fd.fundingNeeded)     lines.push(`- Funding needed: ${fd.fundingNeeded}`)
      if (fd.monthlyRevenue)    lines.push(`- Monthly revenue: ${fd.monthlyRevenue}`)
      if (fd.monthlyExpenses)   lines.push(`- Monthly expenses: ${fd.monthlyExpenses}`)

      const iu = Array.isArray(fd.investmentUtilization) ? fd.investmentUtilization : []
      if (iu.length) {
        lines.push(`- Investment utilization:`)
        for (const r of iu) {
          if (r?.item || r?.amount) lines.push(`  - ${r?.item ?? ""}: ${r?.amount ?? ""}`)
        }
      }

      const fub = Array.isArray(fd.fundingUseBreakdown) ? fd.fundingUseBreakdown : []
      if (fub.length) {
        lines.push(`- Use of funds (user-specified):`)
        for (const r of fub) {
          if (r?.item || r?.amount) lines.push(`  - ${r?.item ?? ""}: ${r?.amount ?? ""}`)
        }
      }

      if (!lines.length) return ""

      return `
FINANCE FACTS (use these exact numbers):
${lines.join("\n")}

STRICT INSTRUCTIONS (enforce consistency):
- "Executive Summary → Funding Requirements & Usage of Funds" AND "Financial Plan → Use of Funds & Runway"
  MUST show a short bullet list of use-of-funds line items with amounts that SUM EXACTLY to "fundingNeeded".
  If the listed items total less than "fundingNeeded", ADD a final line "Working capital and contingency" for the remainder.
  If they exceed "fundingNeeded", REDUCE the last line item so the total equals "fundingNeeded".

- Mirror "Investment utilization" entries in prose (no separate table).
- In "Financial Plan → Key Assumptions", explicitly include a sentence: "Funding received to date: <fundingReceived>."
- In "Financial Plan → Overview", explicitly include a sentence mirroring investment utilization, e.g. "Investment utilization: Marketing: 5,000; Development: 45,000."

- Align "Financial Plan → OpEx":
  If "Monthly expenses" is provided, set each OpEx row (for the visible months) to that same amount.

- Keep all currency strings digits/commas only (no symbols).

- ALSO include these same values at the top level of the JSON as:
  initialInvestment, fundingNeeded, fundingReceived, monthlyRevenue, investmentUtilization.
`
    })()

    // NEW: hints for milestone + notes
    const milestoneHint = (formData as any).upcomingMilestone?.trim()
      ? `OBJECTIVES HINT:
Add this exact sentence at the END of **Company Overview → Company Objectives** (verbatim):
"Upcoming milestone: ${(formData as any).upcomingMilestone}".`
      : ""

    const notesHint = (formData as any).notes?.trim()
      ? `APPENDICES HINT:
Append this note verbatim as the LAST sentence of **Appendices → Management Teams’ Resources**:
"${(formData as any).notes}".`
      : ""

    // System prompt
    const systemPrompt = `You are an expert business-plan writer who produces polished, investor-ready documents.

TASK: Generate a JSON object that matches exactly this shape (no extra keys or markdown):
{
  "initialInvestment": string,
  "fundingNeeded": string,
  "fundingReceived": string,
  "monthlyRevenue": string,
  "investmentUtilization": [ { "item": string, "amount": string } ],

  "notes": string,
  "upcomingMilestone": string,

  "coverPage": { "logo": string },
  "executiveSummary": {
    "businessOverview": string,
    "fundingRequirementsUsageOfFunds": string,
    "pastMilestones": string,
    "problemStatementSolution": string
  },
  "companyOverview": {
    "visionStatement": string,
    "missionStatement": string,
    "companyHistoryBackground": string,
    "foundingTeam": string,
    "legalStructureOwnership": string,
    "coreValuesCulture": string,
    "companyObjectives": string
  },
  "products": {
    "overview": string,
    "product1": string, "product2": string, "product3": string, "product4": string, "product5": string,
    "product6": string, "product7": string, "product8": string, "product9": string, "product10": string,
    "uniqueSellingPropositions": string,
    "developmentRoadmap": string,
    "intellectualPropertyRegulatoryStatus": string
  },
  "marketAnalysis": {
    "industryOverviewSize": string,
    "growthTrendsDrivers": string,
    "underlyingBusinessDrivers": string,
    "targetMarketSegmentation": string,
    "customerPersonasNeeds": string,
    "competitiveLandscapePositioning": string,
    "productsDifferentiation": string,
    "barriersToEntry": string
  },
  "marketingSalesStrategies": {
    "distributionChannels": string,
    "technologyCostStructure": string,
    "customerPricingStructure": string,
    "retentionStrategies": string,
    "integratedFunnelFinancialImpact": string
  },
  "operationsPlan": {
    "overview": string,
    "organizationalStructureTeamResponsibilities": string,
    "infrastructure": string,
    "customerOnboardingToRenewalWorkflow": string,
    "crossFunctionalCommunicationDecisionMaking": string,
    "keyPerformanceMetricsGoals": string
  },
  "managementOrganization": {
    "overview": string,
    "organizationalChart": string,
    "hiringPlanKeyRoles": string
  },
  "financialPlan": {
    "overview": string,
    "keyAssumptions": string,
    "revenueForecast": [ { "period": string, "amount": string } ],
    "cogs": [ { "period": string, "amount": string } ],
    "opEx": [ { "period": string, "amount": string } ],
    "projectedPnl": [ { "period": string, "grossProfit": string, "ebitda": string, "netIncome": string } ],
    "cashFlowRunwayAnalysis": [ { "period": string, "beginningCash": string, "inflows": string, "outflows": string, "endingCash": string, "runwayMonths": string } ],
    "keyFinancialMetricsRatios": string,
    "useOfFundsRunway": string,
    "keySensitivityRiskScenarios": string,
    "summaryOutlook": string
  },
  "riskAnalysisMitigation": {
    "overview": string,
    "marketRisks": string,
    "operationalRisks": string,
    "regulatoryLegalRisks": string,
    "financialRisks": string,
    "contingencyPlans": string
  },
  "appendices": {
    "glossary": string,
    "managementTeamsResources": string,
    "projectedFinancesTables": string
  }
}

RULES:
1) Return STRICT JSON only (no markdown, no comments).
2) Populate each string field at ~50–80 words (tight, specific; no fluff). Never leave any field blank.
3) Products:
   - "overview": ~60–90 words.
   - For each product (product1..product10): ~35–55 words total with 3–4 markdown bullets covering:
     • Core features • Integrations • Target users/industries • Primary use case OR quantified benefit
4) Currency/amount fields must be strings with digits/commas only (no symbols).
5) CRITICAL: The following MUST be non-empty:
   appendices.glossary, appendices.managementTeamsResources, appendices.projectedFinancesTables.
6) No emojis anywhere.
7) Formatting exceptions (markdown allowed ONLY for these two):
   - executiveSummary.businessOverview: paragraph, then **Key Highlights** (hyphen bullets), then **Our Mission** (hyphen bullets).
   - executiveSummary.fundingRequirementsUsageOfFunds: one-line ask, then **Allocation of Funds** (hyphen bullets "<Item> — <Amount>"), then **Objective** (hyphen bullets).`

    const userPrompt = `Generate a comprehensive business plan using this form input.

Make sure you populate the Executive Summary’s "fundingRequirementsUsageOfFunds".
${marketingUserHints}
${achievementsHint}
${financeFacts}
${mileageHintPlaceholder() /* keeps TypeScript happy if removed later */}${milestoneHint}
${notesHint}

FORM DATA:
${JSON.stringify(formData, null, 2)}

Be sure to include the full 'products' section with overview, ten product entries, USPs, development roadmap, and IP/regulatory status.`

    // OpenAI client (v4 SDK)
    const MODEL = (process.env.OPENAI_MODEL ?? "gpt-4o-mini").trim()
    const HEAVY_MODEL = ((process.env.OPENAI_HEAVY_MODEL ?? "").trim()) || MODEL

    const client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
      timeout: 120_000,
    })

    // ── create completion with retries ──
    let completion: Awaited<ReturnType<typeof client.chat.completions.create>>
    const maxRetries = 5
    let attempt = 0
    while (true) {
      try {
        completion = await client.chat.completions.create({
          model: MODEL,
          response_format: { type: "json_object" },
          temperature: 0.2,
          max_tokens: 4500,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
        })
        break
      } catch (err: any) {
        const status = err?.status ?? err?.response?.status
        const code = err?.code
        const headers = err?.headers ?? err?.response?.headers ?? {}
        const transient =
          status === 429 || (status && status >= 500) ||
          code === "ENOTFOUND" || code === "ECONNRESET" || code === "ETIMEDOUT"

        if (transient && attempt < maxRetries) {
          const ra = Number(headers["retry-after"])
          const base = Math.pow(2, attempt) * 1000
          const jitter = Math.random() * base * 0.2
          const delayMs = Number.isFinite(ra) ? ra * 1000 : base + jitter
          console.warn(`Retrying after ${Math.round(delayMs)}ms (attempt ${attempt + 1}/${maxRetries})`, {
            status,
            code,
            retryAfter: ra,
            remainReq: headers["x-ratelimit-remaining-requests"],
            remainTok: headers["x-ratelimit-remaining-tokens"],
          })
          await new Promise(r => setTimeout(r, delayMs))
          attempt++
          continue
        }
        throw err
      }
    }

    // Parse JSON
    let raw = completion.choices?.[0]?.message?.content!
    if (!raw) throw new Error("OpenAI returned no content")
    raw = stripFences(raw)
    {
      const start = raw.indexOf("{")
      const end = raw.lastIndexOf("}")
      if (start !== -1 && end !== -1 && end > start) raw = raw.slice(start, end + 1)
    }

    let parsed: unknown
    try {
      parsed = JSON.parse(raw)
    } catch (firstErr) {
      const start = raw.indexOf("{")
      const end = raw.lastIndexOf("}")
      if (start === -1 || end === -1) throw firstErr
      parsed = JSON.parse(raw.slice(start, end + 1))
    }

    // Validate with Zod
    const planObject = businessPlanSchema.parse(parsed) as any

    // Ensure finance fields exist even if model skipped them
    planObject.initialInvestment ||= (formData as any).initialInvestment ?? ""
    planObject.fundingNeeded     ||= (formData as any).fundingNeeded ?? ""
    planObject.fundingReceived   ||= (formData as any).fundingReceived ?? ""
    planObject.monthlyRevenue    ||= (formData as any).monthlyRevenue ?? ""
    if (!Array.isArray(planObject.investmentUtilization)) {
      planObject.investmentUtilization = Array.isArray((formData as any).investmentUtilization)
        ? (formData as any).investmentUtilization
        : []
    }

    // ✅ persist notes + upcomingMilestone from formData
    planObject.notes ||= (formData as any).notes ?? ""
    planObject.upcomingMilestone ||= (formData as any).upcomingMilestone ?? ""

    // Safety net: never leave Appendices blank
    planObject.appendices.glossary = ensure(
      planObject.appendices.glossary,
      "Glossary: concise definitions of key terms used throughout the plan, including core product, market, financial, and operational terminology."
    )
    planObject.appendices.managementTeamsResources = ensure(
      planObject.appendices.managementTeamsResources,
      "Summary of management team resources: leadership bios, advisory support, hiring roadmap, and external specialist partnerships."
    )
    planObject.appendices.projectedFinancesTables = ensure(
      planObject.appendices.projectedFinancesTables,
      "Projected finances overview: revenue, COGS, OpEx, EBITDA and cash-flow summaries for the next 12–24 months."
    )

    // Logo guard so the UI doesn't render invalid src
    if (!planObject.coverPage.logo || !/^https?:\/\//i.test(planObject.coverPage.logo)) {
      planObject.coverPage.logo = "/logo-placeholder.png"
    }

    // Normalize financials to enforce totals & alignment (before balancing)
    normalizeFinancials(planObject, formData)

    // Enforce structured Business Overview (intro + highlights + mission)
    structureExecBusinessOverview(planObject, formData)

    // Pick a working model for balancing
    const BALANCE = (process.env.BALANCE_SECTIONS ?? "1") === "1"
    let BALANCER_MODEL = ((process.env.OPENAI_HEAVY_MODEL ?? "").trim()) || (process.env.OPENAI_MODEL ?? "gpt-4o-mini").trim()
    if (BALANCER_MODEL !== (process.env.OPENAI_MODEL ?? "gpt-4o-mini").trim()) {
      try {
        await client.chat.completions.create({
          model: BALANCER_MODEL,
          messages: [{ role: "user", content: "ping" }],
          max_tokens: 1,
          temperature: 0,
        })
      } catch {
        console.warn(`Heavy model '${BALANCER_MODEL}' unavailable; falling back to '${MODEL}' for balancing.`)
        BALANCER_MODEL = MODEL
      }
    }

    // ⬇️ CALL the top-level balancer BEFORE enforceInclusions
    await balancePlanSections({
      client,
      model: BALANCER_MODEL,
      plan: planObject,
      formData,
      enable: BALANCE,
    })

    // ✅ Guarantee required insertions AFTER balancing so they won’t get removed
    enforceInclusions(planObject, formData)

    // Auth
    const { data: { user } } = await supabase.auth.getUser()
    if (!user?.id) return { success: false, error: "Not authenticated" }

    // Upsert user
    const { error: upsertUserErr } = await supabase
      .from("users")
      .upsert(
        { id: user.id, email: user.email, full_name: (user.user_metadata as any)?.full_name },
        { onConflict: "email" }
      )
    if (upsertUserErr) return { success: false, error: upsertUserErr.message }

    const planName = (formData.businessName ?? "").trim()

    // Insert or update the plan
    const { data: existing } = await supabase
      .from("business_plans")
      .select("id")
      .eq("user_id", user.id)
      .eq("plan_name", planName)
      .maybeSingle()

    let planId = existing?.id as string | undefined

    if (planId) {
      const { error: updateErr } = await supabase
        .from("business_plans")
        .update({ plan_data: planObject, updated_at: new Date().toISOString() })
        .eq("id", planId)
      if (updateErr) return { success: false, error: updateErr.message }
    } else {
      const { data: inserted, error: insertErr } = await supabase
        .from("business_plans")
        .insert({ user_id: user.id, plan_name: planName, plan_data: planObject })
        .select("id")
        .single()
      if (insertErr || !inserted?.id) {
        return { success: false, error: insertErr?.message ?? "Insert failed" }
      }
      planId = inserted.id
    }

    // Link any unmatched payment
    const { data: latestPayment } = await supabase
      .from("payments")
      .select("id")
      .eq("user_id", user.id)
      .is("plan_id", null)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle()

    if (latestPayment?.id) {
      await supabase.from("payments").update({ plan_id: planId }).eq("id", latestPayment.id)
    }

    return { success: true, plan: planObject as GeneratedPlan, planId: planId! }
  } catch (err: any) {
    console.error("Error generating business plan:", err)
    return { success: false, error: err?.message ?? "Unknown error" }
  }
}

// Helper to keep TS happy if we strip out the milestoneHint interpolation
function mileageHintPlaceholder() { return "" }
